import pandas as pd
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QComboBox, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import numpy as np
from datetime import datetime

class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=10, height=6, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.ax = fig.add_subplot(111)
        super().__init__(fig)
        self.setParent(parent)

    def plot_summary(self, tape_data, scrap_data, title, xlabel, color_map, machines, avg_tape, avg_scrap):
        self.ax.clear()

        width = 0.3  # Width of the bars
        positions = list(range(len(tape_data)))  # Positions of the months

        # Plot tape data for each machine
        bottoms = pd.Series([0] * len(tape_data), index=tape_data.index)
        for machine in machines:
            if machine in tape_data.columns:
                self.ax.bar(positions, tape_data[machine], width, bottom=bottoms, color=color_map[machine], label=machine, zorder=3)
                bottoms += tape_data[machine]

        # Plot scrap data next to each machine's tape data
        for pos, month in enumerate(tape_data.index):
            for machine in machines:
                try:
                    if machine in tape_data.columns and machine in scrap_data.columns:
                        scrap_length = scrap_data.loc[month, machine]
                        tape_length = tape_data.loc[month, machine]
                        if tape_length > 0 and scrap_length > 0:
                            percentage = (scrap_length / tape_length) * 100
                            self.ax.bar(pos + width, scrap_length, width, bottom=tape_data.loc[month, machines].cumsum().shift(1).fillna(0)[machine], color='tab:red', label='Scrap' if pos == 0 and machine == machines[0] else "", zorder=3)
                            self.ax.text(pos + width, scrap_length / 2 + tape_data.loc[month, machines].cumsum().shift(1).fillna(0)[machine], f'{round(percentage)}%', ha='center', va='baseline', color='black', fontsize=10)
                except KeyError:
                    # Skip this machine if there's a KeyError
                    continue

        # Plot average bars after the monthly data
        avg_position = len(tape_data)
        avg_bottoms = 0
        for i, machine in enumerate(machines):
            try:
                avg_tape_value = avg_tape.get(machine, 0)
                avg_scrap_value = avg_scrap.get(machine, 0)
                if avg_tape_value > 0:
                    self.ax.bar(avg_position, avg_tape_value, width, bottom=avg_bottoms, color=color_map[machine], label='Average Tape' if i == 0 else "", zorder=3)
                    percentage = (avg_scrap_value / avg_tape_value) * 100 if avg_tape_value else 0
                    self.ax.bar(avg_position + width, avg_scrap_value, width, bottom=avg_bottoms, color='tab:red', label='Average Scrap' if i == 0 else "", zorder=3)
                    self.ax.text(avg_position + width, avg_scrap_value / 2 + avg_bottoms, f'{round(percentage)}%', ha='center', va='baseline', color='black', fontsize=10)
                avg_bottoms += avg_tape_value
            except KeyError:
                # Skip this machine if there's a KeyError
                continue

        # Draw a thin black line to separate December and average bars
        self.ax.axvline(x=avg_position - 0.5, color='black', linewidth=1)

        self.ax.set_title(title)
        self.ax.set_xlabel(xlabel)
        self.ax.set_ylabel('Length [m]')
        self.ax.tick_params(axis='x', direction='in', which='both')
        self.ax.tick_params(axis='y', direction='in', which='both')

        self.ax.grid(axis='y', color='gray', linestyle='-', linewidth=0.5, zorder=0)

        self.ax.set_xticks([pos + width / 2 for pos in positions] + [avg_position + width / 2])
        self.ax.set_xticklabels(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Avg'], rotation=0)

        handles, labels = self.ax.get_legend_handles_labels()
        machine_handles = [handles[machines.index(machine)] for machine in machines if machine in tape_data.columns]
        machine_labels = [machine for machine in machines if machine in tape_data.columns]

        machine_handles.reverse()
        machine_labels.reverse()
        handles = [handles[-1]] + machine_handles
        labels = ['Scrap per Machine'] + machine_labels

        self.ax.legend(handles, labels, loc='upper left')

        self.draw()
        self.flush_events()

    def plot_average_length(self, avg_tape, title, color_map, machines, product_value=None, show_percentage=False):
        self.ax.clear()

        width = 0.5  # Width of the bars
        positions = list(range(len(machines) + (1 if product_value is not None else 0)))  # Positions of the machines plus one for the product

        # Plot average length for each machine
        epol0e_avg_tape_nein = avg_tape.get('EPOL0E_nein', 0)  # Default to 0 to avoid division by zero
        epol0e_avg_tape_ja = avg_tape.get('EPOL0E_ja', 0)  # Default to 0 to avoid division by zero
        epol0e_total_avg_tape = epol0e_avg_tape_nein + epol0e_avg_tape_ja

        if isinstance(epol0e_avg_tape_nein, pd.Series):
            epol0e_avg_tape_nein = epol0e_avg_tape_nein.sum()
        if isinstance(epol0e_avg_tape_ja, pd.Series):
            epol0e_avg_tape_ja = epol0e_avg_tape_ja.sum()
        if isinstance(epol0e_total_avg_tape, pd.Series):
            epol0e_total_avg_tape = epol0e_total_avg_tape.sum()

        for i, machine in enumerate(machines):
            if machine == 'EPOL0E':
                avg_tape_nein = avg_tape.get('EPOL0E_nein', 0)
                avg_tape_ja = avg_tape.get('EPOL0E_ja', 0)
                if isinstance(avg_tape_nein, pd.Series):
                    avg_tape_nein = avg_tape_nein.sum()
                if isinstance(avg_tape_ja, pd.Series):
                    avg_tape_ja = avg_tape_ja.sum()
                self.ax.bar(positions[i], avg_tape_nein, width, color='tab:blue', label='EPOL0E_nein', zorder=3)
                self.ax.bar(positions[i], avg_tape_ja, width, bottom=avg_tape_nein, color='xkcd:sky', label='EPOL0E_ja', zorder=3)
                self.ax.text(positions[i], avg_tape_nein / 2, '100%', ha='center', va='center', color='black', fontsize=10)
                self.ax.text(positions[i], avg_tape_nein + 5, f'{round(avg_tape_nein)}', ha='center', color='black', fontsize=10)
                ja_percentage = (avg_tape_ja / epol0e_total_avg_tape) * 100 if epol0e_total_avg_tape else 0
                self.ax.text(positions[i], avg_tape_nein + avg_tape_ja / 2, f'{round(100 + ja_percentage)}%', ha='center', va='center', color='black', fontsize=10)
                self.ax.text(positions[i], epol0e_total_avg_tape + 5, f'{round(epol0e_total_avg_tape)}', ha='center', color='black', fontsize=10)
            else:
                avg_tape_value = avg_tape.get(machine, 0)
                if isinstance(avg_tape_value, pd.Series):
                    avg_tape_value = avg_tape_value.sum()
                self.ax.bar(positions[i], avg_tape_value, width, color=color_map[machine], label=machine, zorder=3)
                self.ax.text(positions[i], avg_tape_value + 5, f'{round(avg_tape_value)}', ha='center', color='black', fontsize=10)
                if show_percentage:
                    percentage = (avg_tape_value / epol0e_avg_tape_nein) * 100 if epol0e_avg_tape_nein else 0
                    self.ax.text(positions[i], avg_tape_value / 2, f'{round(percentage)}%', ha='center', color='black', fontsize=10)

        # Plot the product bar if provided
        if product_value is not None:
            product_percentage = (product_value / epol0e_avg_tape_nein) * 100 if epol0e_avg_tape_nein else 0
            self.ax.bar(positions[-1], product_value, width, color='gold', label='Product uBL', zorder=3)
            self.ax.text(positions[-1], product_value + 5, f'{round(product_value)}', ha='center', color='black', fontsize=10)
            self.ax.text(positions[-1], product_value / 2, f'{round(product_percentage)}%', ha='center', color='black', fontsize=10)

        self.ax.set_title(title)
        self.ax.set_ylabel('Average Length [m]')
        self.ax.tick_params(axis='x', direction='in', which='both')
        self.ax.tick_params(axis='y', direction='in', which='both')

        self.ax.grid(axis='y', color='gray', linestyle='-', linewidth=0.5, zorder=0)

        self.ax.set_xticks(positions)
        self.ax.set_xticklabels(machines + (['Product uBL'] if product_value is not None else []), rotation=0)

        handles, labels = self.ax.get_legend_handles_labels()
        machine_handles = [handles[machines.index(machine)] for machine in machines if machine in avg_tape.keys()]
        machine_labels = [machine for machine in machines if machine in avg_tape.keys()]

        self.draw()
        self.flush_events()

    def calculate_averages(self, df):
        current_month = datetime.now().month
        current_year = datetime.now().year

        # Filter out the data for the current month if it is not fully completed
        if not df.empty:
            if current_year in df['Year'].values:
                df = df[~((df['Year'] == current_year) & (df['Month'] == current_month))]

        # Calculate the averages based on the available months
        tape_data = df.groupby('Machine')['Bandlänge'].sum()
        coating_scrap_data = df.groupby('Machine')['Ausschusslänge'].sum()
        if 'Messungsausschuss' in df.columns:
            measurement_scrap_data = df.groupby('Machine')['Messungsausschuss'].sum()
        else:
            measurement_scrap_data = pd.Series(0, index=coating_scrap_data.index)
        scrap_data = coating_scrap_data + measurement_scrap_data

        # Calculate averages for Bandlänge_nein and Bandlänge_ja for EPOL0E if available
        if 'Bandlänge_nein' in df.columns:
            tape_data_nein = df[df['Machine'] == 'EPOL0E'].groupby('Machine')['Bandlänge_nein'].sum()
            tape_data_ja = df[df['Machine'] == 'EPOL0E'].groupby('Machine')['Bandlänge_ja'].sum()

            avg_tape = tape_data / len(df['Month'].unique())
            avg_scrap = scrap_data / len(df['Month'].unique())

            avg_tape['EPOL0E_nein'] = tape_data_nein / len(df['Month'].unique())
            avg_tape['EPOL0E_ja'] = tape_data_ja / len(df['Month'].unique())
        else:
            avg_tape = tape_data / len(df['Month'].unique())
            avg_scrap = scrap_data / len(df['Month'].unique())

        return avg_tape.to_dict(), avg_scrap.to_dict()

class SummaryTab(QWidget):
    def __init__(self, machines, color_map, machine_order, show_product=False):
        super().__init__()
        self.machines = machines
        self.color_map = color_map
        self.machine_order = machine_order
        self.show_product = show_product

        # Initialize combo boxes here
        self.year_combo_table = QComboBox()
        self.year_combo_plot = QComboBox()
        self.year_combo_output = QComboBox()

        self.initialize_ui()

    def initialize_ui(self):
        self.tabs = QTabWidget()
        self.plot_tab = QWidget()
        self.output_tab = QWidget()
        self.table_tab = QWidget()

        self.tabs.addTab(self.plot_tab, "Plot")
        self.tabs.addTab(self.output_tab, "Output")
        self.tabs.addTab(self.table_tab, "Table")

        self.setup_plot_tab()
        self.setup_output_tab()
        self.setup_table_tab()

        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        self.setLayout(layout)

        # Call load_initial_data after setting up all tabs
        self.load_initial_data()

    def setup_table_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.show_button_table = QPushButton("Show Summary Data")
        self.show_button_table.clicked.connect(self.show_summary_data)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Machine", "Tape [m]", "Coating Scrap [m]", "Measurement Scrap [m]", "Full Scrap [m]", "Yield [%]"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        controls_layout.addWidget(self.year_combo_table)
        controls_layout.addWidget(self.show_button_table)

        layout.addLayout(controls_layout)
        layout.addWidget(self.table)
        self.table_tab.setLayout(layout)

    def setup_plot_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.plot_button_plot = QPushButton("Plot Summary Data")
        self.plot_button_plot.clicked.connect(self.plot_summary_data)

        self.canvas_plot = PlotCanvas(self, width=10, height=6)
        self.canvas_plot.setVisible(False)

        controls_layout.addWidget(self.year_combo_plot)
        controls_layout.addWidget(self.plot_button_plot)

        layout.addLayout(controls_layout)
        layout.addWidget(self.canvas_plot, 1)
        layout.addStretch()
        self.plot_tab.setLayout(layout)

    def setup_output_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.plot_button_output = QPushButton("Show Average Lengths")
        self.plot_button_output.clicked.connect(self.plot_average_lengths)

        self.canvas_output = PlotCanvas(self, width=10, height=6)
        self.canvas_output.setVisible(False)

        controls_layout.addWidget(self.year_combo_output)
        controls_layout.addWidget(self.plot_button_output)

        layout.addLayout(controls_layout)
        layout.addWidget(self.canvas_output, 1)
        layout.addStretch()
        self.output_tab.setLayout(layout)

    def load_initial_data(self):
        years = set()
        for machine in self.machines.values():
            if hasattr(machine, 'df'):
                years.update(machine.df['Year'].unique())

        current_year = datetime.now().year
        current_month = datetime.now().month

        for combo in [self.year_combo_table, self.year_combo_plot, self.year_combo_output]:
            combo.clear()  # Clear the combo box before adding items
            for year in sorted(years, reverse=True):
                combo.addItem(str(int(year)))  # Add the full year option first

                if year < current_year or (year == current_year and current_month >= 12):
                    combo.addItem(f"{year} Q4")
                if year < current_year or (year == current_year and current_month >= 9):
                    combo.addItem(f"{year} Q3")
                if year < current_year or (year == current_year and current_month >= 6):
                    combo.addItem(f"{year} Q2")
                if year < current_year or (year == current_year and current_month >= 3):
                    combo.addItem(f"{year} Q1")

            if year == current_year:
                combo.addItem(str(int(year)))  # Add the full year option again for the current year

    def gather_data(self, selected_period):
        dfs = []
        current_year = datetime.now().year
        current_month = datetime.now().month

        if ' Q' in selected_period:
            year, quarter = selected_period.split(' Q')
            year = int(year)
            quarter = int(quarter)
            if quarter == 1:
                months = [1, 2, 3]
            elif quarter == 2:
                months = [4, 5, 6]
            elif quarter == 3:
                months = [7, 8, 9]
            elif quarter == 4:
                months = [10, 11, 12]
        else:
            year = int(selected_period)
            months = list(range(1, 13))
            if year == current_year:
                months = [month for month in months if month < current_month]

        for machine_name, machine in self.machines.items():
            if hasattr(machine, 'df'):
                df = machine.df.copy()
                df['Machine'] = machine_name
                df['Bandlänge'] = pd.to_numeric(df['Bandlänge'], errors='coerce')
                df['Ausschusslänge'] = pd.to_numeric(df['Ausschusslänge'], errors='coerce')
                if 'Messungsausschuss' in df.columns:
                    df['Messungsausschuss'] = pd.to_numeric(df['Messungsausschuss'], errors='coerce')
                else:
                    df['Messungsausschuss'] = np.nan
                df['Prozess-Datum'] = pd.to_datetime(df['Prozess-Datum'], errors='coerce')
                df = df[(df['Year'] == year) & (df['Month'].isin(months))]

                # Separate Bandlänge into Bandlänge_nein and Bandlänge_ja for EPOL0E
                if machine_name == 'EPOL0E':
                    df['Bandlänge_nein'] = df.apply(lambda row: row['Bandlänge'] if row['Zugband'] == 'nein' else 0, axis=1)
                    df['Bandlänge_ja'] = df.apply(lambda row: row['Bandlänge'] if row['Zugband'] == 'ja' else 0, axis=1)

                dfs.append(df)

        if dfs:
            return pd.concat(dfs, ignore_index=True)
        else:
            return pd.DataFrame()

    def show_summary_data(self):
        selected_period = self.year_combo_table.currentText()
        if not selected_period:
            print("No period selected.")
            return

        df = self.gather_data(selected_period)
        if df.empty:
            print("No data available.")
            return

        summary = df.groupby('Machine').agg({
            'Bandlänge': 'sum',
            'Ausschusslänge': 'sum',
            'Messungsausschuss': 'sum'
        })
        summary['Yield [%]'] = ((summary['Bandlänge'] - summary['Ausschusslänge'] - summary['Messungsausschuss'].fillna(0)) / summary['Bandlänge']) * 100

        if 'EPOL0E' in summary.index and 'Bandlänge_nein' in df.columns:
            # Add EPOL0E tape to the summary only for uBL tab
            epol0e_tape = df[df['Machine'] == 'EPOL0E'].groupby('Machine')['Bandlänge_nein'].sum()
            summary.loc['EPOL0E tape', 'Bandlänge'] = epol0e_tape.get('EPOL0E', 0)
            summary.loc['EPOL0E tape', 'Ausschusslänge'] = summary.loc['EPOL0E', 'Ausschusslänge']
            summary.loc['EPOL0E tape', 'Messungsausschuss'] = summary.loc['EPOL0E', 'Messungsausschuss']

            # Calculate yield percentage for EPOL0E tape
            bandlänge = summary.loc['EPOL0E tape', 'Bandlänge']
            ausschusslänge = summary.loc['EPOL0E tape', 'Ausschusslänge']
            messungsausschuss = summary.loc['EPOL0E tape', 'Messungsausschuss']
            yield_percentage = ((bandlänge - ausschusslänge - (messungsausschuss if not pd.isnull(messungsausschuss) else 0)) / bandlänge) * 100 if bandlänge != 0 else np.nan
            summary.loc['EPOL0E tape', 'Yield [%]'] = yield_percentage

        self.table.setRowCount(0)
        if 'EPOL0E tape' in summary.index:
            machine_order = ['EPOL0E tape'] + self.machine_order
        else:
            machine_order = self.machine_order

        for i, machine in enumerate(machine_order):
            if machine in summary.index:
                row = summary.loc[machine]
                self.table.insertRow(i)
                self.table.setItem(i, 0, QTableWidgetItem(machine))
                self.table.setItem(i, 1, QTableWidgetItem(f"{row['Bandlänge']:.0f}"))
                self.table.setItem(i, 2, QTableWidgetItem(f"{row.get('Ausschusslänge', 0):.0f}"))
                self.table.setItem(i, 3, QTableWidgetItem(f"{row.get('Messungsausschuss', 0):.0f}"))
                ausschusslänge = 0 if pd.isnull(row.get('Ausschusslänge')) else int(row.get('Ausschusslänge'))
                messungsausschuss = 0 if pd.isnull(row.get('Messungsausschuss')) else int(row.get('Messungsausschuss'))
                full_scrap = ausschusslänge + messungsausschuss
                self.table.setItem(i, 4, QTableWidgetItem(f"{full_scrap:.0f}"))

                yield_percentage = row['Yield [%]']
                if pd.notnull(yield_percentage):
                    self.table.setItem(i, 5, QTableWidgetItem(f"{round(yield_percentage)}"))
                else:
                    self.table.setItem(i, 5, QTableWidgetItem('N/A'))

                for col in range(self.table.columnCount()):
                    item = self.table.item(i, col)
                    if item:
                        item.setTextAlignment(Qt.AlignCenter)

    def plot_summary_data(self):
        selected_period = self.year_combo_plot.currentText()
        if not selected_period:
            print("No period selected.")
            return

        df = self.gather_data(selected_period)
        if df.empty:
            print("No data available.")
            return

        df['Month'] = df['Prozess-Datum'].dt.month
        tape_data = df.groupby(['Month', 'Machine'])['Bandlänge'].sum().unstack(fill_value=0)
        scrap_data = df.groupby(['Month', 'Machine'])['Ausschusslänge'].sum().unstack(fill_value=0)

        # Plot only Bandlänge_nein for EPOL0E if available
        if 'Bandlänge_nein' in df.columns:
            tape_data['EPOL0E'] = df[df['Machine'] == 'EPOL0E'].groupby('Month')['Bandlänge_nein'].sum()

        all_months = range(1, 13)
        tape_data = tape_data.reindex(all_months, fill_value=0)
        scrap_data = scrap_data.reindex(all_months, fill_value=0)

        available_machines = [machine for machine in self.machines.keys() if machine in tape_data.columns]

        avg_tape, avg_scrap = self.canvas_plot.calculate_averages(df)

        self.canvas_plot.setVisible(True)
        self.canvas_plot.plot_summary(tape_data, scrap_data, f'Summary of Data for {selected_period}', 'Month', self.color_map, available_machines, avg_tape, avg_scrap)
        self.canvas_plot.draw()
        self.canvas_plot.flush_events()

    def plot_average_lengths(self):
        selected_period = self.year_combo_output.currentText()
        if not selected_period:
            print("No period selected.")
            return

        df = self.gather_data(selected_period)
        if df.empty:
            print("No data available.")
            return

        avg_tape, avg_scrap = self.canvas_output.calculate_averages(df)

        # Calculate the "Product" value for "TSXL uBL" if in uBL tab
        product_value = None
        if self.show_product:
            tsxl_ubl_avg_tape = avg_tape.get('TSXL uBL', 0)
            tsxl_ubl_yield = (1 - avg_scrap.get('TSXL uBL', 0) / tsxl_ubl_avg_tape) * 100 if tsxl_ubl_avg_tape else 0
            product_value = tsxl_ubl_avg_tape * tsxl_ubl_yield / 100

        title = f'Average Monthly {"uBL" if self.show_product else "kBL"} Input Tape Lengths for {selected_period} {"(percentagewise relative to EPOL0E)" if self.show_product else ''}'
        self.canvas_output.setVisible(True)
        self.canvas_output.plot_average_length(avg_tape, title, self.color_map, self.machine_order, product_value, show_percentage=self.show_product)
        self.canvas_output.draw()
        self.canvas_output.flush_events()

class Summary(QWidget):
    def __init__(self, epol0e, isd1a, deck1a, seed1a, sl1ab, ag1a, schn1a, me1a_ag, me1a_cu, tsxl_ubl):
        super().__init__()
        self.epol0e = epol0e
        self.isd1a = isd1a
        self.deck1a = deck1a
        self.seed1a = seed1a
        self.sl1ab = sl1ab
        self.ag1a = ag1a
        self.schn1a = schn1a
        self.me1a_ag = me1a_ag
        self.me1a_cu = me1a_cu
        self.tsxl_ubl = tsxl_ubl
        self.initialize_ui()

    def initialize_ui(self):
        self.tabs = QTabWidget()
        self.ubl_tab = SummaryTab(
            {
                'EPOL0E': self.epol0e,
                'ISD1A': self.isd1a,
                'DECK1A': self.deck1a,
                'SEED1A': self.seed1a,
                'SL1A\\SL1B': self.sl1ab,
                'AG1A': self.ag1a,
                'TSXL uBL': self.tsxl_ubl
            },
            {
                'EPOL0E': 'tab:blue',
                'ISD1A': 'tab:orange',
                'DECK1A': 'tab:green',
                'SEED1A': 'tab:purple',
                'SL1A\\SL1B': 'tab:cyan',
                'AG1A': 'tab:olive',
                'TSXL uBL': 'tab:pink',
                'EPOL0E tape': 'xkcd:sky'  # Add color for EPOL0E tape
            },
            ['EPOL0E', 'ISD1A', 'DECK1A', 'SEED1A', 'SL1A\\SL1B', 'AG1A', 'TSXL uBL'],
            show_product=True
        )
        self.kbl_tab = SummaryTab(
            {
                'SCHN1A': self.schn1a,
                'ME1A Ag': self.me1a_ag,
                'ME1A Cu': self.me1a_cu
            },
            {
                'SCHN1A': 'black',
                'ME1A Ag': 'tab:gray',
                'ME1A Cu': 'tab:brown'
            },
            ['SCHN1A', 'ME1A Ag', 'ME1A Cu'],
            show_product=False
        )

        self.tabs.addTab(self.ubl_tab, "uBL")
        self.tabs.addTab(self.kbl_tab, "kBL")

        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        self.setLayout(layout)