from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

class Information(QWidget):
    def __init__(self, parent=None):
        super(Information, self).__init__(parent)
        self.initialize_ui()

    def initialize_ui(self):
        layout = QVBoxLayout()

        info_label = QLabel(self)
        info_label.setFont(QFont("Arial", 14))
        info_label.setText(
            "This program is an yield analyst tool of uBL and kBL input\\output tape length. \n"
            "It mirrors the available data in XLS files, which is being manually provided by QC department. \n"
            "Each machine has its own weekly, monthly, and yearly data divided by all input length and scrap length. \n"
            "Coating Scrap and Measurement Scrap are tape scraps determined by QC department respectively after coating process and after TSXL measurement. \n"
            "Measurement Scrap in each machine assigned to the specific tape number; in TSXL it is assigned to the date of the tape measurement. \n"
            "There may be missing scrap length data before July 2024. \n"
            "\n"
            "Path to data: \n"
            "◯ EPOL0E: P:\\QP\\02_Datenübersicht\\F010_EPOL_Übersicht.xlsm \n"
            "◯ ISD1A: P:\\QP\\02_Datenübersicht\\03_Qualitätsprüfung\\Prozesse\\F020.xlsm \n"
            "◯ DECK1A: P:\\QP\\02_Datenübersicht\\03_Qualitätsprüfung\\Prozesse\\F030.xlsm \n"
            "◯ SEED1A: P:\\QP\\02_Datenübersicht\\03_Qualitätsprüfung\\Prozesse\\F040.xlsm \n"
            "◯ SL1A\\SL1B: P:\\QP\\02_Datenübersicht\\03_Qualitätsprüfung\\Prozesse\\F051-1.xlsm \n"
            "◯ AG1A: P:\\QP\\02_Datenübersicht\\03_Qualitätsprüfung\\Prozesse\\F070.xlsm \n"
            "◯ TSXL uBL: P:\\QP\\81_Tools\\Tapestar\\Bänderliste.xlsx \n"
            "◯ SCHN1A: P:\\QP\\02_Datenübersicht\\F215_Uebersicht.xlsm \n"
            "◯ ME1A Ag: P:\\QP\\02_Datenübersicht\\F240_XRF_Uebersicht.xlsm \n"
            "◯ ME1A Cu: P:\\QP\\02_Datenübersicht\\F240_XRF_Uebersicht.xlsm \n"
        )
        info_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(info_label)

        self.setLayout(layout)

 