import pandas as pd
from PyQt5.QtWidgets import QTabWidget, QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from datetime import datetime, timedelta
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import warnings

# Suppress specific warnings
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.ax = fig.add_subplot(111)
        fig.subplots_adjust()  # Adjust margins
        super().__init__(fig)
        self.setParent(parent)

    def plot_histograms(self, data, title, xlabel, error_origins):
        self.ax.clear()
        colors = {
            'In': 'tab:pink',
            'EPOL0E': 'tab:blue',
            'ISD1A': 'tab:orange',
            'DECK1A': 'tab:green',
            'SEED1A': 'tab:purple',
            'SL1A\\SL1B': 'tab:cyan',
            'AG1A': 'tab:olive',
            'Unknown': 'tab:red'
        }

        tape_data = data[['In']]
        scrap_data = data.drop(columns=['In'])

        tape_data.plot(kind='bar', ax=self.ax, alpha=1, zorder=3, color=[colors['In']], position=1, width=0.3)
        scrap_data.plot(kind='bar', stacked=True, ax=self.ax, alpha=1, zorder=3, color=[colors[col] for col in scrap_data.columns], position=0, width=0.3)

        # Adjust x-axis limits to add padding
        self.ax.set_xlim(-0.5, len(data) - 0.5)

        self.ax.set_title(title)
        self.ax.set_xlabel(xlabel)
        self.ax.set_ylabel('Length [m]')
        self.ax.tick_params(axis='x', direction='in', which='both')
        self.ax.tick_params(axis='y', direction='in', which='both')
        self.ax.grid(axis='y', color='gray', linestyle='-', linewidth=0.5, zorder=0)
        
        legend_labels = ['Tape', 'EPOL0E', 'ISD1A', 'DECK1A', 'SEED1A', 'SL1A\\SL1B', 'AG1A', 'Unknown']
        self.ax.legend(legend_labels)

        for i in range(len(data)):
            tape_length = data.iloc[i]['In']
            cumulative_scrap = 0
            for scrap_origin in scrap_data.columns:
                scrap_length = data.iloc[i][scrap_origin]
                if tape_length > 0 and scrap_length > 0:
                    percentage = (scrap_length / tape_length) * 100
                    self.ax.text(i + 0.09, cumulative_scrap + scrap_length / 2, f'{round(percentage)}%', ha='left', va='center', color='black', fontsize=10)
                    cumulative_scrap += scrap_length

            total_scrap_length = scrap_data.iloc[i].sum()
            if tape_length > 0 and total_scrap_length > 0:
                total_percentage = (total_scrap_length / tape_length) * 100
                self.ax.text(i + 0.09, cumulative_scrap, f'{round(total_percentage)}%', ha='left', va='baseline', color='black', fontsize=10)

        self.draw()

class TSXLSubTab(QWidget):
    def __init__(self, tab_name, filter_standard=False, filter_type=None):
        super().__init__()
        self.tab_name = tab_name
        self.filter_standard = filter_standard
        self.filter_type = filter_type
        self.initialize_ui()

    def initialize_ui(self):
        self.tabs = QTabWidget()
        self.week_tab = QWidget()
        self.month_tab = QWidget()
        self.year_tab = QWidget()
        self.error_tab = QWidget()
        self.product_tab = QWidget()  # New Product tab

        self.tabs.addTab(self.week_tab, "Week")
        self.tabs.addTab(self.month_tab, "Month")
        self.tabs.addTab(self.year_tab, "Year")
        self.tabs.addTab(self.error_tab, "Specific Errors")
        self.tabs.addTab(self.product_tab, "Product")  # Add Product tab
        
        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        self.setLayout(layout)

        self.setup_week_tab()
        self.setup_month_tab()
        self.setup_year_tab()
        self.setup_error_tab()
        self.setup_product_tab()  # Setup for Product tab
        self.load_initial_data()

    def setup_week_tab(self):
        layout = QVBoxLayout()
        self.year_combo = QComboBox()
        self.week_combo = QComboBox()
        self.report_button = QPushButton("Generate Report")
        self.report_button.clicked.connect(self.generate_report)
        
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Tape", "Type", "Test", "In [m]", "Out [m]", "Yield"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        header = self.table.horizontalHeader()
        for i in range(self.table.columnCount()):
            header.setDefaultAlignment(Qt.AlignCenter)
        
        controls_layout = QHBoxLayout()
        controls_layout.addWidget(self.year_combo)
        controls_layout.addWidget(self.week_combo)
        controls_layout.addWidget(self.report_button)
        
        layout.addLayout(controls_layout)
        layout.addWidget(self.table)
        self.week_tab.setLayout(layout)

    def setup_month_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.year_combo_month = QComboBox()
        self.month_combo = QComboBox()
        self.plot_button_month = QPushButton("Plot Weekly Data")
        self.plot_button_month.clicked.connect(self.plot_monthly_data)

        months = [datetime(2000, m, 1).strftime('%B') for m in range(1, 13)][::-1]
        self.month_combo.addItems(months)

        controls_layout.addWidget(self.year_combo_month)
        controls_layout.addWidget(self.month_combo)
        controls_layout.addWidget(self.plot_button_month)

        self.canvas_month = PlotCanvas(self, width=8, height=6)
        self.canvas_month.setVisible(False)

        layout.addLayout(controls_layout)
        layout.addWidget(self.canvas_month, 1)
        layout.addStretch()
        self.month_tab.setLayout(layout)

        self.year_combo_month.currentIndexChanged.connect(self.update_month_combo)

    def setup_year_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.year_combo_year = QComboBox()
        self.plot_button_year = QPushButton("Plot Monthly Data")
        self.plot_button_year.clicked.connect(self.plot_yearly_data)

        controls_layout.addWidget(self.year_combo_year)
        controls_layout.addWidget(self.plot_button_year)

        self.canvas_year = PlotCanvas(self, width=8, height=6)
        self.canvas_year.setVisible(False)
        
        layout.addLayout(controls_layout)
        layout.addWidget(self.canvas_year, 1)
        layout.addStretch()
        self.year_tab.setLayout(layout)

    def setup_error_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.year_combo_error = QComboBox()
        self.week_combo_error = QComboBox()
        self.report_button_error = QPushButton("Generate Report")
        self.report_button_error.clicked.connect(self.generate_error_report)

        self.error_table = QTableWidget()
        self.error_table.setColumnCount(8)
        self.error_table.setHorizontalHeaderLabels(["Tape", "Type", "Test", "Error Origin", "Error Type", "Error Cause", "Scrap [m]", "Scrap Yield"])
        self.error_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        controls_layout.addWidget(self.year_combo_error)
        controls_layout.addWidget(self.week_combo_error)
        controls_layout.addWidget(self.report_button_error)

        layout.addLayout(controls_layout)
        layout.addWidget(self.error_table)
        self.error_tab.setLayout(layout)

    def center_table_items(self):
        for row in range(self.table.rowCount()):
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if item:
                    item.setTextAlignment(Qt.AlignCenter)

    def load_initial_data(self):
        file_path = r"P:\QP\81_Tools\Tapestar\Bänderliste.xlsx"
        try:
            df = pd.read_excel(file_path, sheet_name='Bänderliste_uBL', skiprows=3, usecols="B,C,D,F,H,L,T,Z,AD,AI,AJ,AK",
                               converters={'F': lambda x: pd.to_datetime(x, format='%d.%m.%Y', errors='coerce')})
            df.columns = ['Tape', 'Test', 'Type', 'Date', 'In', 'Length_HP', 'Length_ST', 'Length_AP', 'Length_for_kBL', 'Error_Origin', 'Error_Type', 'Error_Cause']
            df.dropna(subset=['Date'], inplace=True)

            df['Year'] = df['Date'].dt.year
            df['Month'] = df['Date'].dt.month
            df['Week'] = df['Date'].dt.isocalendar().week

            def determine_length(row):
                if row['Type'] == 'HP':
                    return row['Length_HP']
                elif row['Type'] == 'ST':
                    return row['Length_ST']
                else:
                    return row['Length_AP']

            #df['Out'] = df.apply(determine_length, axis=1)
            df['Out'] = df['Length_for_kBL']
            df['Scrap'] = df['In'] - df['Out']

            df['Test'] = df['Test'].apply(lambda x: 'Yes' if str(x).strip().lower() == 'ja' else 'No')

            df['Prozess-Datum'] = df['Date']
            df['Bandlänge'] = df['In']
            df['Ausschusslänge'] = df['Scrap']

            if self.filter_standard:
                df = df[df['Type'].str.contains('ST', na=False)]

            if self.filter_type:
                df = df[df['Type'] == self.filter_type]

            self.df = df

            valid_years = df['Year'].dropna().unique()
            sorted_years = sorted(valid_years, reverse=True)

            for combo in [self.year_combo, self.year_combo_month, self.year_combo_year, self.year_combo_error]:
                combo.clear()
                combo.addItems([str(int(year)) for year in sorted_years])

            self.year_combo.currentIndexChanged.connect(self.update_week_combo)
            self.year_combo_error.currentIndexChanged.connect(self.update_week_combo_error)
            self.update_week_combo()
            self.update_week_combo_error()

        except Exception as e:
            print(f"Failed to load data: {e}")

    def update_week_combo(self):
        if self.year_combo.count() == 0:
            return

        selected_year = int(self.year_combo.currentText())
        df_filtered = self.df[self.df['Year'] == selected_year]
        valid_weeks = sorted(df_filtered['Week'].unique(), reverse=True)

        self.week_combo.clear()
        self.week_combo.addItems([str(week) for week in valid_weeks])

    def update_week_combo_error(self):
        if self.year_combo_error.count() == 0:
            return

        selected_year = int(self.year_combo_error.currentText())
        df_filtered = self.df[(self.df['Year'] == selected_year) & self.df['Error_Origin'].notna()]
        valid_weeks = sorted(df_filtered['Week'].unique(), reverse=True)

        self.week_combo_error.clear()
        self.week_combo_error.addItems([str(week) for week in valid_weeks])

    def update_month_combo(self):
        selected_year = int(self.year_combo_month.currentText()) if self.year_combo_month.count() > 0 else None
        if selected_year is None:
            return

        df_filtered = self.df[self.df['Year'] == selected_year]
        available_months = sorted(df_filtered['Month'].unique(), reverse=True)

        self.month_combo.clear()
        self.month_combo.addItems([datetime(2000, int(m), 1).strftime('%B') for m in available_months])

    def generate_report(self):
        try:
            selected_week = int(self.week_combo.currentText())
        except ValueError:
            print("No week selected.")
            return

        selected_year = int(self.year_combo.currentText())
        start_of_week = datetime.strptime(f'{selected_year} {selected_week} 1', "%G %V %u")
        end_of_week = start_of_week + timedelta(days=6)

        try:
            df_filtered = self.df[(self.df['Date'] >= start_of_week) & (self.df['Date'] <= end_of_week)]

            self.table.setRowCount(0)

            for index, row in df_filtered.iterrows():
                tape = str(row['Tape']) if not pd.isnull(row['Tape']) else ""
                in_val = int(row['In']) if not pd.isnull(row['In']) else 0
                out_val = int(row['Out']) if not pd.isnull(row['Out']) else 0
                yield_val = f"{(out_val / in_val * 100):.2f}%" if in_val != 0 else "N/A"
                type_val = row['Type']
                test_val = row['Test']

                row_position = self.table.rowCount()
                self.table.insertRow(row_position)
                self.table.setItem(row_position, 0, QTableWidgetItem(tape))
                self.table.setItem(row_position, 1, QTableWidgetItem(type_val))
                self.table.setItem(row_position, 2, QTableWidgetItem(test_val))
                self.table.setItem(row_position, 3, QTableWidgetItem(str(in_val)))
                self.table.setItem(row_position, 4, QTableWidgetItem(str(out_val)))
                self.table.setItem(row_position, 5, QTableWidgetItem(yield_val))

                for col in range(self.table.columnCount()):
                    item = self.table.item(row_position, col)
                    if item:
                        item.setTextAlignment(Qt.AlignCenter)

        except Exception as e:
            print(f"Failed to generate report: {e}")

    def generate_error_report(self):
        try:
            selected_week = int(self.week_combo_error.currentText())
        except ValueError:
            print("No week selected.")
            return

        selected_year = int(self.year_combo_error.currentText())
        start_of_week = datetime.strptime(f'{selected_year} {selected_week} 1', "%G %V %u")
        end_of_week = start_of_week + timedelta(days=6)

        try:
            df_filtered = self.df[(self.df['Date'] >= start_of_week) & (self.df['Date'] <= end_of_week) & self.df['Error_Origin'].notna()]

            self.error_table.setRowCount(0)

            for index, row in df_filtered.iterrows():
                tape = str(row['Tape']) if not pd.isnull(row['Tape']) else ""
                type_val = row['Type']
                test_val = row['Test']
                error_origin_val = str(row['Error_Origin']) if not pd.isnull(row['Error_Origin']) else ""
                error_type_val = str(row['Error_Type']) if not pd.isnull(row['Error_Type']) else ""
                error_cause_val = str(row['Error_Cause']) if not pd.isnull(row['Error_Cause']) else ""
                scrap_val = round(row['In'] - row['Length_for_kBL'])
                scrap_perc = f"{((row['In'] - row['Length_for_kBL']) / row['In'] * 100):.2f}%"

                row_position = self.error_table.rowCount()
                self.error_table.insertRow(row_position)
                self.error_table.setItem(row_position, 0, QTableWidgetItem(tape))
                self.error_table.setItem(row_position, 1, QTableWidgetItem(type_val))
                self.error_table.setItem(row_position, 2, QTableWidgetItem(test_val))
                self.error_table.setItem(row_position, 3, QTableWidgetItem(error_origin_val))
                self.error_table.setItem(row_position, 4, QTableWidgetItem(error_type_val))
                self.error_table.setItem(row_position, 5, QTableWidgetItem(error_cause_val))
                self.error_table.setItem(row_position, 6, QTableWidgetItem(str(scrap_val)))
                self.error_table.setItem(row_position, 7, QTableWidgetItem(str(scrap_perc)))

                for col in range(self.error_table.columnCount()):
                    item = self.error_table.item(row_position, col)
                    if item:
                        item.setTextAlignment(Qt.AlignCenter)

        except Exception as e:
            print(f"Failed to generate error report: {e}")

    def plot_monthly_data(self):
        if self.year_combo_month.count() == 0 or self.month_combo.count() == 0:
            print("No year or month selected.")
            return

        self.canvas_month.setVisible(True)
        selected_year = int(self.year_combo_month.currentText())
        selected_month = datetime.strptime(self.month_combo.currentText(), '%B').month

        try:
            df_filtered = self.df[(self.df['Year'] == selected_year) & (self.df['Month'] == selected_month)]

            weekly_data = df_filtered.groupby('Week').agg({'In': 'sum', 'Scrap': 'sum'}).astype(float)

            error_origins = ['EPOL0E', 'ISD1A', 'DECK1A', 'SEED1A', 'SL1A\\SL1B', 'AG1A']
            for origin in error_origins:
                weekly_data[origin] = 0.0

            weekly_data['Unknown'] = weekly_data['Scrap']
            for _, row in df_filtered.iterrows():
                week = row['Week']
                if row['Error_Origin'] in ['SL1A', 'SL1B']:
                    row['Error_Origin'] = 'SL1A\\SL1B'
                if row['Error_Origin'] in error_origins:
                    scrap_length = float(row['In']) - float(row['Length_for_kBL'])
                    weekly_data.at[week, row['Error_Origin']] += scrap_length
                    weekly_data.at[week, 'Unknown'] -= scrap_length

            weekly_data['Unknown'] = weekly_data['Unknown'].apply(lambda x: max(x, 0))  # Ensure no negative values

            self.canvas_month.plot_histograms(weekly_data[['In'] + error_origins + ['Unknown']], f"TSXL uBL {self.tab_name} Weekly Data for {selected_year}, {self.month_combo.currentText()}", 'Week', error_origins)
            
            # Set the x-axis labels to be horizontal
            self.canvas_month.ax.set_xticks(range(len(weekly_data.index)))
            self.canvas_month.ax.set_xticklabels(weekly_data.index.astype(int), rotation=0, ha='center')

        except Exception as e:
            print(f"Failed to process or plot data: {e}")

    def plot_yearly_data(self):
        selected_year_text = self.year_combo_year.currentText()
        try:
            selected_year = int(float(selected_year_text))
        except ValueError as e:
            print(f"Error converting year: {e}")
            return
        
        self.canvas_year.setVisible(True)

        try:
            df_filtered = self.df[self.df['Year'] == selected_year]

            monthly_data = df_filtered.groupby('Month').agg({'In': 'sum', 'Scrap': 'sum'}).astype(float)

            error_origins = ['EPOL0E', 'ISD1A', 'DECK1A', 'SEED1A', 'SL1A\\SL1B', 'AG1A']
            for origin in error_origins:
                monthly_data[origin] = 0.0

            monthly_data['Unknown'] = monthly_data['Scrap']
            for _, row in df_filtered.iterrows():
                month = row['Month']
                if row['Error_Origin'] in ['SL1A', 'SL1B']:
                    row['Error_Origin'] = 'SL1A\\SL1B'
                if row['Error_Origin'] in error_origins:
                    scrap_length = float(row['In']) - float(row['Length_for_kBL'])
                    monthly_data.at[month, row['Error_Origin']] += scrap_length
                    monthly_data.at[month, 'Unknown'] -= scrap_length

            monthly_data['Unknown'] = monthly_data['Unknown'].apply(lambda x: max(x, 0))  # Ensure no negative values

            self.canvas_year.plot_histograms(monthly_data[['In'] + error_origins + ['Unknown']], f"TSXL uBL {self.tab_name} Monthly Data for {selected_year}", 'Month', error_origins)
            self.canvas_year.ax.set_xticklabels(monthly_data.index.map(lambda x: datetime(2000, x, 1).strftime('%b')), rotation=0)

        except Exception as e:
            print(f"Failed to process or plot data: {e}")

    def setup_product_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.year_combo_product = QComboBox()
        self.report_button_product = QPushButton("Generate Report")
        self.report_button_product.clicked.connect(self.plot_product_data)

        controls_layout.addWidget(self.year_combo_product)
        controls_layout.addWidget(self.report_button_product)

        self.canvas_product = PlotCanvas(self, width=8, height=6)
        self.canvas_product.setVisible(False)

        layout.addLayout(controls_layout)
        layout.addWidget(self.canvas_product, 1)
        layout.addStretch()
        self.product_tab.setLayout(layout)

        self.year_combo_product.currentIndexChanged.connect(self.update_product_combo)

    def update_product_combo(self):
        selected_year = int(self.year_combo_product.currentText()) if self.year_combo_product.count() > 0 else None
        if selected_year is None:
            return

    def plot_product_data(self):
        selected_year = int(self.year_combo_product.currentText())
        if selected_year is None:
            return

        try:
            df_filtered = self.df[self.df['Year'] == selected_year]

            monthly_data = df_filtered.groupby('Month').agg({
                'Length_for_kBL': 'sum',
                'In': 'sum'
            }).astype(float)

            monthly_data['Yield'] = (monthly_data['Length_for_kBL'] / monthly_data['In']) * 100

            self.canvas_product.setVisible(True)
            self.canvas_product.ax.clear()

            # Add horizontal grid lines first to ensure they are behind the bars
            self.canvas_product.ax.grid(True, axis='y', linestyle='-', linewidth=0.5, color='gray', zorder=1)

            # Plotting bar chart with zorder to ensure bars are above the grid lines
            bars = self.canvas_product.ax.bar(monthly_data.index, monthly_data['Length_for_kBL'], color='gold', alpha=1, label='Tape', zorder=2)

            # Creating a second axis for the yield percentage, ensuring it's above the bars
            ax2 = self.canvas_product.ax.twinx()
            ax2.plot(monthly_data.index, monthly_data['Yield'], color='tab:red', marker='o', linestyle='-', linewidth=2, label='Yield [%]', zorder=3)

            # Annotating each bar with the length on top of the bars and below the yield
            for bar in bars:
                height = bar.get_height()
                self.canvas_product.ax.annotate(f'{round(height)}',
                                                xy=(bar.get_x() + bar.get_width() / 2, height),
                                                xytext=(0, 5),  # 5 points vertical offset
                                                textcoords="offset points",
                                                ha='center', va='bottom', zorder=4)

            # Annotating each point with the yield on top of the length annotations
            for i in range(len(monthly_data)):
                ax2.annotate(f'{round(monthly_data["Yield"].iloc[i])}%',
                            xy=(monthly_data.index[i], monthly_data['Yield'].iloc[i]),
                            xytext=(0, 5),  # 5 points vertical offset
                            textcoords="offset points",
                            ha='center', va='bottom', color='red', zorder=5)

            # Set the x-axis ticks inside
            self.canvas_product.ax.tick_params(axis='x', direction='in', which='both')
            self.canvas_product.ax.tick_params(axis='y', direction='in', which='both')
            ax2.tick_params(axis='y', direction='in', which='both')

            # Set the Yield axis to a fixed range of 0 to 100%
            ax2.set_ylim(0, 100)

            # Labels and titles
            self.canvas_product.ax.set_xlabel('Month')
            self.canvas_product.ax.set_ylabel('Length [m]')
            ax2.set_ylabel('Yield [%]')

            self.canvas_product.ax.set_title(f'uBL Product Data for {selected_year}')
            self.canvas_product.ax.set_xticks(monthly_data.index)
            self.canvas_product.ax.set_xticklabels(monthly_data.index.map(lambda x: datetime(2000, x, 1).strftime('%b')), rotation=0)

            self.canvas_product.ax.legend(loc='upper left')
            ax2.legend(loc='upper right')

            self.canvas_product.draw()

        except Exception as e:
            print(f"Failed to generate product plot: {e}")

class TSXL_uBL(QWidget):
    def __init__(self):
        super().__init__()
        self.all_tab = TSXLSubTab(tab_name="All", filter_standard=False)
        self.standard_tab = TSXLSubTab(tab_name="ST", filter_standard=True)
        self.ap_tab = TSXLSubTab(tab_name="AP", filter_standard=False, filter_type='AP')
        self.df = None

        self.initialize_ui()

    def initialize_ui(self):
        self.tabs = QTabWidget()
        self.tabs.addTab(self.all_tab, "All")
        self.tabs.addTab(self.standard_tab, "ST")
        self.tabs.addTab(self.ap_tab, "AP")

        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        self.setLayout(layout)

        self.load_data_from_tabs()

    def load_data_from_tabs(self):
        self.df = self.all_tab.df if self.all_tab.df is not None else pd.DataFrame()

        # Populate the year combo boxes for the Product tab
        for tab in [self.all_tab, self.standard_tab, self.ap_tab]:
            tab.year_combo_product.addItems([str(int(year)) for year in sorted(self.df['Year'].dropna().unique(), reverse=True)])
