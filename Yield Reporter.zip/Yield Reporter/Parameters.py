from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

class Parameters(QWidget):
    def __init__(self, parent=None):
        super(Parameters, self).__init__(parent)
        self.initialize_ui()

    def initialize_ui(self):
        layout = QVBoxLayout()

        info_label = QLabel(self)
        info_label.setFont(QFont("Arial", 14))
        info_label.setText(
            "Possible error origins: EPOLOE, ISD1A, DECK1A, SEED1A, SL1A\\SL1B, AG1A, OX1A, SCHN1A, ME1A Ag\\Cu, Unknown \n"
            "\n"
            "Possible error types: \n"
            "m menschlich \n"
            "t Technik \n"
            "p Prozess \n"
            "\n"
            "Possible causes of errors: \n"
            "UN	unbekannt \n"
            "SO	Sonstiges \n"
            "mPV Prozessvorbereitung \n"
            "mDO Falsche Eingabe\\Dokumentation \n"
            "tZS Zugspannung \n"
            "tSA Stromausfall \n"
            "tEE elektrische Einheiten \n"
            "tME mechanische Einheiten \n"
            "pVE Verdampfung \n"
            "pTE Temperatur \n"
        )
        info_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(info_label)

        self.setLayout(layout)

 