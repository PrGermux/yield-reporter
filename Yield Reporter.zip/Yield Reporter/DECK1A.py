import pandas as pd
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, QTabWidget
from PyQt5.QtCore import Qt
from datetime import datetime, timedelta
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.ax = fig.add_subplot(111)
        fig.subplots_adjust()  # Adjust margins
        super().__init__(fig)
        self.setParent(parent)

    def plot_histograms(self, data, title, xlabel):
        self.ax.clear()
        data['Bandlänge'] = pd.to_numeric(data['Bandlänge'], errors='coerce')
        data['Ausschusslänge'] = pd.to_numeric(data['Ausschusslänge'], errors='coerce')
        data['Messungsausschuss'] = pd.to_numeric(data['Messungsausschuss'], errors='coerce')

        data[['Bandlänge']].plot(kind='bar', ax=self.ax, alpha=1, rot=0, zorder=3, position=1, color='tab:green', width=0.3)  # Stacked bars
        data[['Ausschusslänge', 'Messungsausschuss']].plot(kind='bar', ax=self.ax, alpha=1, rot=0, zorder=3, position=0, color=['tab:red', 'tab:pink'], stacked=True, width=0.3)  # Stacked bars
        self.ax.set_title(title)
        self.ax.set_xlabel(xlabel)
        self.ax.set_ylabel('Length [m]')
        self.ax.tick_params(axis='x', direction='in', which='both')  # Ticks inside for x-axis
        self.ax.tick_params(axis='y', direction='in', which='both')  # Ticks inside for y-axis

        self.ax.set_xlim(-0.5, len(data) - 0.5)
        
        # Configure grid
        self.ax.grid(axis='y', color='gray', linestyle='-', linewidth=0.5, zorder=0)  # Ensure grid is behind bars with zorder=0
        
        # Setup legend with labels renamed
        legend_labels = ['Tape', 'Coating scrap', 'Measurement scrap']  # Rename labels for clarity
        self.ax.legend(legend_labels)

        # Add percentages on the Scrap bars
        for i in range(len(data)):
            tape_length = data.iloc[i]['Bandlänge']
            coating_scrap_length = data.iloc[i]['Ausschusslänge']
            measurement_scrap_length = data.iloc[i]['Messungsausschuss']
            all_scrap_length = coating_scrap_length + measurement_scrap_length
            if tape_length > 0:
                if coating_scrap_length > 0:
                    percentage = (coating_scrap_length / tape_length) * 100
                    self.ax.text(i + 0.09, coating_scrap_length / 2, f'{round(percentage)}%', ha='left', va='center', color='black', fontsize=10)
                if measurement_scrap_length > 0:
                    percentage = (measurement_scrap_length / tape_length) * 100
                    self.ax.text(i + 0.09, coating_scrap_length + (measurement_scrap_length / 2), f'{round(percentage)}%', ha='left', va='center', color='black', fontsize=10)
                if all_scrap_length > 0:
                    percentage = (all_scrap_length / tape_length) * 100
                    self.ax.text(i + 0.09, all_scrap_length, f'{round(percentage)}%', ha='left', va='baseline', color='black', fontsize=10)

        self.draw()

class DECK1A(QWidget):
    def __init__(self):
        super().__init__()
        self.initialize_ui()

    def initialize_ui(self):        
        self.DECK1A_tabs = QTabWidget()
        self.week_tab = QWidget()
        self.month_tab = QWidget()
        self.year_tab = QWidget()
        
        self.DECK1A_tabs.addTab(self.week_tab, "Week")
        self.DECK1A_tabs.addTab(self.month_tab, "Month")
        self.DECK1A_tabs.addTab(self.year_tab, "Year")
        
        DECK1A_layout = QVBoxLayout()
        DECK1A_layout.addWidget(self.DECK1A_tabs)
        self.setLayout(DECK1A_layout)

        self.setup_week_tab()
        self.setup_month_tab()
        self.setup_year_tab()
        self.load_initial_data()

    def setup_week_tab(self):
        layout = QVBoxLayout()
        self.year_combo = QComboBox()
        self.week_combo = QComboBox()
        self.report_button = QPushButton("Generate Report")
        self.report_button.clicked.connect(self.generate_report)
        
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Tape", "In [m]", "Out [m]", "Yield", "Error", "Test"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)  # Adjust table width to match window width

        header = self.table.horizontalHeader()
        for i in range(self.table.columnCount()):
            header.setDefaultAlignment(Qt.AlignCenter)
        
        controls_layout = QHBoxLayout()
        controls_layout.addWidget(self.year_combo)
        controls_layout.addWidget(self.week_combo)
        controls_layout.addWidget(self.report_button)
        
        layout.addLayout(controls_layout)
        layout.addWidget(self.table)
        self.week_tab.setLayout(layout)

    def update_week_combo(self):
        if self.year_combo.count() == 0:
            return

        selected_year = int(self.year_combo.currentText())
        df_filtered = self.df1[self.df1['Year'] == selected_year]
        valid_weeks = sorted(df_filtered['Week'].dropna().unique(), reverse=True)

        self.week_combo.clear()
        self.week_combo.addItems([str(week) for week in valid_weeks])

    def setup_month_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()
        
        self.year_combo_month = QComboBox()
        self.month_combo = QComboBox()
        self.plot_button_month = QPushButton("Plot Monthly Data")
        self.plot_button_month.clicked.connect(self.plot_monthly_data)

        months = [datetime(2000, m, 1).strftime('%B') for m in range(1, 13)][::-1]  # Months in descending order
        self.month_combo.addItems(months)

        controls_layout.addWidget(self.year_combo_month)
        controls_layout.addWidget(self.month_combo)
        controls_layout.addWidget(self.plot_button_month)

        self.canvas_month = PlotCanvas(self, width=8, height=6)
        self.canvas_month.setVisible(False)

        layout.addLayout(controls_layout)
        layout.addWidget(self.canvas_month, 1)
        layout.addStretch()
        self.month_tab.setLayout(layout)

        self.year_combo_month.currentIndexChanged.connect(self.update_month_combo)

    def update_month_combo(self):
        selected_year = int(self.year_combo_month.currentText()) if self.year_combo_month.count() > 0 else None
        if selected_year is None:
            return

        df_filtered = self.df1[self.df1['Year'] == selected_year]
        available_months = sorted(df_filtered['Month'].dropna().unique(), reverse=True)

        self.month_combo.clear()
        self.month_combo.addItems([datetime(2000, int(m), 1).strftime('%B') for m in available_months])

    def setup_year_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.year_combo_year = QComboBox()
        self.plot_button_year = QPushButton("Plot Monthly Data")
        self.plot_button_year.clicked.connect(self.plot_yearly_data)

        controls_layout.addWidget(self.year_combo_year)
        controls_layout.addWidget(self.plot_button_year)

        self.canvas_year = PlotCanvas(self, width=8, height=6)
        self.canvas_year.setVisible(False)
        
        layout.addLayout(controls_layout)
        layout.addWidget(self.canvas_year, 1)
        layout.addStretch()
        self.year_tab.setLayout(layout)

    def center_table_items(self):
        for row in range(self.table.rowCount()):
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if item:
                    item.setTextAlignment(Qt.AlignCenter)

    def load_initial_data(self):
        try:
            # Load data from the first file
            file_path1 = r"P:\QP\02_Datenübersicht\03_Qualitätsprüfung\Prozesse\F030.xlsm"
            sheets1 = ['Daten_EP', 'Daten']
            dfs1 = []

            for sheet in sheets1:
                df = pd.read_excel(file_path1, sheet_name=sheet, skiprows=2,
                                converters={'Prozess-Datum': lambda x: pd.to_datetime(x, format='%d.%m.%Y', errors='coerce')})
                df.dropna(subset=['Prozess-Datum'], inplace=True)
                df['Test'] = df['Test'].apply(lambda x: 'Yes' if str(x).strip().lower() == 'ja' else 'No')
                dfs1.append(df)

            self.df1 = pd.concat([df for df in dfs1 if not df.empty], ignore_index=True)

            # Add Year, Month, and Week columns to df1
            self.df1['Year'] = self.df1['Prozess-Datum'].dt.year
            self.df1['Month'] = self.df1['Prozess-Datum'].dt.month
            self.df1['Week'] = self.df1['Prozess-Datum'].dt.isocalendar().week

            # Load data from the second file
            file_path2 = r"P:\QP\81_Tools\Tapestar\Bänderliste.xlsx"
            df2 = pd.read_excel(file_path2, sheet_name='Bänderliste_uBL', skiprows=3,
                                usecols="B,C,D,F,H,L,T,Z,AD,AI,AJ,AK",
                                converters={'F': lambda x: pd.to_datetime(x, format='%d.%m.%Y', errors='coerce')})
            df2.columns = ['Tape', 'Test', 'Type', 'Date', 'In', 'Length_HP', 'Length_ST', 'Length_AP', 'Length_for_kBL', 'Error_Origin', 'Error_Type', 'Error_Cause']
            df2.dropna(subset=['Date'], inplace=True)

            # Replace 'Date' in df2 with the 'Prozess-Datum' from df1 based on matching 'Tape' and 'Bandnummer'
            date_map = self.df1.set_index('Bandnummer')['Prozess-Datum'].to_dict()
            df2['Date'] = df2['Tape'].map(date_map)

            # Add Year, Month, and Week columns to df2 based on updated Date
            df2['Year'] = df2['Date'].dt.year
            df2['Month'] = df2['Date'].dt.month
            df2['Week'] = df2['Date'].dt.isocalendar().week
            df2 = df2[df2['Error_Origin'] == 'DECK1A']

            def determine_length(row):
                if row['Type'] == 'HP':
                    return row['Length_HP']
                elif row['Type'] == 'ST':
                    return row['Length_ST']
                else:
                    return row['Length_AP']

            #df2['Out'] = df2.apply(determine_length, axis=1)
            df2['Out'] = df2['Length_for_kBL']
            df2['Scrap'] = df2['In'] - df2['Out']
            df2['Test'] = df2['Test'].apply(lambda x: 'Yes' if str(x).strip().lower() == 'ja' else 'No')

            # Calculate Messungsausschuss
            df2['Messungsausschuss'] = df2.apply(lambda row: float(row['In']) - float(row['Length_for_kBL']), axis=1)
            df2['Prozess-Datum'] = pd.to_datetime(df2['Date'])

            # Ensure 'Bandnummer' column exists in df2 before merging
            if 'Bandnummer' not in df2.columns:
                df2['Bandnummer'] = df2['Tape']  # Assuming 'Tape' corresponds to 'Bandnummer'

            # Replace df2 with the updated dataframe that has aligned dates
            self.df2 = df2

            valid_years = self.df1['Year'].dropna().unique()
            sorted_years = sorted(valid_years, reverse=True)

            for combo in [self.year_combo, self.year_combo_month, self.year_combo_year]:
                combo.clear()
                combo.addItems([str(int(year)) for year in sorted_years])

            self.year_combo.currentIndexChanged.connect(self.update_month_combo)
            self.update_month_combo()  # Call to fill month combo initially
            self.year_combo.currentIndexChanged.connect(self.update_week_combo)
            if self.year_combo.count() > 0:
                self.update_week_combo()  # Update immediately after loading

            # Important for Summary.py
            self.df = self.df1.copy()  # Use a copy to ensure original data is intact
            if 'Bandnummer' in self.df1.columns and 'Messungsausschuss' in self.df2.columns:
                self.df = self.df.merge(self.df2[['Bandnummer', 'Messungsausschuss']], on='Bandnummer', how='left')

        except Exception as e:
            print(f"Failed to load data: {e}")

    def plot_yearly_data(self):
        selected_year_text = self.year_combo_year.currentText()
        try:
            selected_year = int(selected_year_text)
        except ValueError as e:
            print(f"Error converting year: {e}")
            return

        self.canvas_year.setVisible(True)

        try:
            df_filtered = self.df1[self.df1['Year'] == selected_year]

            # Ensure columns are numeric
            df_filtered.loc[:, 'Bandlänge'] = pd.to_numeric(df_filtered['Bandlänge'], errors='coerce').fillna(0)
            df_filtered.loc[:, 'Ausschusslänge'] = pd.to_numeric(df_filtered['Ausschusslänge'], errors='coerce').fillna(0)

            # Aggregate data by month
            monthly_data = df_filtered.groupby('Month').agg({'Bandlänge': 'sum', 'Ausschusslänge': 'sum'}).astype(float)

            # Align Messungsausschuss with its own dates from the merged dataframe
            df2_filtered = self.df2[self.df2['Year'] == selected_year]
            df2_filtered['Messungsausschuss'] = pd.to_numeric(df2_filtered['Messungsausschuss'], errors='coerce').fillna(0)
            measurement_scrap = df2_filtered.groupby('Month')['Messungsausschuss'].sum()
            monthly_data['Messungsausschuss'] = measurement_scrap

            # Rename index to abbreviated month names
            monthly_data.index = [datetime(2000, month, 1).strftime('%b') for month in monthly_data.index.astype(int)]

            self.canvas_year.plot_histograms(monthly_data, f"DECK1A Monthly Data for {selected_year}", 'Month')

        except Exception as e:
            print(f"Failed to process or plot data: {e}")

    def generate_report(self):
        try:
            selected_week = int(self.week_combo.currentText())
        except ValueError:
            print("No week selected.")
            return

        selected_year = int(self.year_combo.currentText())
        start_of_week = datetime.strptime(f'{selected_year} {selected_week} 1', "%Y %W %w")
        end_of_week = start_of_week + timedelta(days=6)

        try:
            df_filtered = self.df1[(self.df1['Prozess-Datum'] >= start_of_week) & (self.df1['Prozess-Datum'] <= end_of_week)]

            # Clear existing rows from the table
            self.table.setRowCount(0)

            # Populate the table with data from df_filtered
            for index, row in df_filtered.iterrows():
                tape = str(row['Bandnummer']) if not pd.isnull(row['Bandnummer']) else ""
                in_val = int(row['Bandlänge']) if not pd.isnull(row['Bandlänge']) else 0
                out_val = in_val - int(row['Ausschusslänge']) if not pd.isnull(row['Ausschusslänge']) else 0
                yield_val = f"{(out_val / in_val * 100):.2f}%" if in_val != 0 else "N/A"
                error_val = str(row['Ursache']) if not pd.isnull(row['Ursache']) else ""
                test_val = 'Yes' if row['Test'] == 'Yes' else 'No'

                row_position = self.table.rowCount()
                self.table.insertRow(row_position)
                self.table.setItem(row_position, 0, QTableWidgetItem(tape))
                self.table.setItem(row_position, 1, QTableWidgetItem(str(in_val)))
                self.table.setItem(row_position, 2, QTableWidgetItem(str(out_val)))
                self.table.setItem(row_position, 3, QTableWidgetItem(yield_val))
                self.table.setItem(row_position, 4, QTableWidgetItem(error_val))
                self.table.setItem(row_position, 5, QTableWidgetItem(test_val))

                for col in range(self.table.columnCount()):
                    item = self.table.item(row_position, col)
                    if item:
                        item.setTextAlignment(Qt.AlignCenter)

        except Exception as e:
            print(f"Failed to generate report: {e}")

    def plot_monthly_data(self):
        if self.year_combo_month.count() == 0 or self.month_combo.count() == 0:
            print("No year or month selected.")
            return
        
        self.canvas_month.setVisible(True)
        selected_year = int(self.year_combo_month.currentText())
        selected_month = datetime.strptime(self.month_combo.currentText(), '%B').month

        try:
            # Filter for the selected year and month
            df_filtered = self.df1[(self.df1['Year'] == selected_year) & (self.df1['Month'] == selected_month)].copy()
            
            # Ensure columns are numeric
            df_filtered.loc[:, 'Bandlänge'] = pd.to_numeric(df_filtered['Bandlänge'], errors='coerce').fillna(0)
            df_filtered.loc[:, 'Ausschusslänge'] = pd.to_numeric(df_filtered['Ausschusslänge'], errors='coerce').fillna(0)

            # Group by week and sum the relevant columns
            weekly_data = df_filtered.groupby('Week').agg({'Bandlänge': 'sum', 'Ausschusslänge': 'sum'}).astype(float)

            # Align Messungsausschuss with its own dates from the merged dataframe
            measurement_scrap = self.df2[(self.df2['Year'] == selected_year) & (self.df2['Month'] == selected_month)].groupby('Week')['Messungsausschuss'].sum()
            weekly_data['Messungsausschuss'] = measurement_scrap

            # Ensure the plot includes only weeks within the selected month
            weeks_in_month = df_filtered['Week'].unique()

            # Reindex, convert types, and fill missing values
            weekly_data = weekly_data.reindex(sorted(weeks_in_month)).infer_objects()
            weekly_data = weekly_data.fillna(0).astype(float)  # Fill missing weeks with zero

            self.canvas_month.plot_histograms(weekly_data, f"DECK1A Weekly Data for {selected_year}, {self.month_combo.currentText()}", 'Week')

        except Exception as e:
            print(f"Failed to process or plot data: {e}")

    def plot_yearly_data(self):
        selected_year_text = self.year_combo_year.currentText()
        try:
            selected_year = int(selected_year_text)
        except ValueError as e:
            print(f"Error converting year: {e}")
            return
        
        self.canvas_year.setVisible(True)

        try:
            df_filtered = self.df1[self.df1['Year'] == selected_year].copy()

            # Ensure columns are numeric
            df_filtered.loc[:, 'Bandlänge'] = pd.to_numeric(df_filtered['Bandlänge'], errors='coerce').fillna(0)
            df_filtered.loc[:, 'Ausschusslänge'] = pd.to_numeric(df_filtered['Ausschusslänge'], errors='coerce').fillna(0)

            # Aggregate data by month
            monthly_data = df_filtered.groupby('Month').agg({'Bandlänge': 'sum', 'Ausschusslänge': 'sum'}).astype(float)

            # Align Messungsausschuss with its own dates from the merged dataframe
            df2_filtered = self.df2[self.df2['Year'] == selected_year]
            df2_filtered['Messungsausschuss'] = pd.to_numeric(df2_filtered['Messungsausschuss'], errors='coerce').fillna(0)
            measurement_scrap = df2_filtered.groupby('Month')['Messungsausschuss'].sum()
            monthly_data['Messungsausschuss'] = measurement_scrap

            # Rename index to abbreviated month names
            monthly_data.index = [datetime(2000, month, 1).strftime('%b') for month in monthly_data.index.astype(int)]

            self.canvas_year.plot_histograms(monthly_data, f"DECK1A Monthly Data for {selected_year}", 'Month')

        except Exception as e:
            print(f"Failed to process or plot data: {e}")