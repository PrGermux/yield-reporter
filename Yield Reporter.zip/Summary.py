import pandas as pd
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QComboBox, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from EPOL0E import EPOL0E
from ISD1A import ISD1A
from DECK1A import DECK1A
from SEED1A import SEED1A
from SL1AB import SL1AB
from AG1A import AG1A
from SCHN1A import SCHN1A
from ME1A_Ag import ME1A_Ag
from ME1A_Cu import ME1A_Cu
from TSXL import TSXL

class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=10, height=6, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.ax = fig.add_subplot(111)
        super().__init__(fig)
        self.setParent(parent)

    def plot_summary(self, tape_data, scrap_data, title, xlabel, color_map, machines):
        self.ax.clear()

        tape_data = tape_data[machines]
        tape_data.plot(kind='bar', stacked=True, ax=self.ax, position=0, width=0.4, color=[color_map[machine] for machine in machines], zorder=3)

        scrap_data.plot(kind='bar', ax=self.ax, position=1, width=0.4, color='tab:red', label='Scrap', zorder=3)

        # Set titles and labels
        self.ax.set_title(title)
        self.ax.set_xlabel(xlabel)
        self.ax.set_ylabel('Length [m]')
        self.ax.tick_params(axis='x', direction='in', which='both')  # Ticks inside for x-axis
        self.ax.tick_params(axis='y', direction='in', which='both')  # Ticks inside for y-axis

        self.ax.grid(axis='y', color='gray', linestyle='-', linewidth=0.5, zorder=0)

        # Set x-tick labels
        self.ax.set_xticks(range(12))
        self.ax.set_xticklabels(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], rotation=0)

        # Create custom legend
        handles, labels = self.ax.get_legend_handles_labels()
        machine_handles = [handles[machines.index(machine)] for machine in machines if machine in tape_data.columns]
        machine_labels = [machine for machine in machines if machine in tape_data.columns]

        # Reverse the order of handles and labels, then move Scrap to the end
        machine_handles.reverse()
        machine_labels.reverse()
        handles = [handles[-1]] + machine_handles  # Scrap first
        labels = ['Scrap'] + machine_labels

        self.ax.legend(handles, labels, loc='upper right')

        # Redraw the canvas
        self.draw()
        self.flush_events()

class SummaryTab(QWidget):
    def __init__(self, machines, color_map, machine_order):
        super().__init__()
        self.machines = machines
        self.color_map = color_map
        self.machine_order = machine_order
        self.initialize_ui()

    def initialize_ui(self):
        self.tabs = QTabWidget()
        self.table_tab = QWidget()
        self.plot_tab = QWidget()

        self.tabs.addTab(self.table_tab, "Table")
        self.tabs.addTab(self.plot_tab, "Plot")

        self.setup_table_tab()
        self.setup_plot_tab()

        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        self.setLayout(layout)

    def setup_table_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.year_combo_table = QComboBox()
        self.show_button_table = QPushButton("Show Summary Data")
        self.show_button_table.clicked.connect(self.show_summary_data)
        
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Machine", "Tape [m]", "Scrap [m]", "Yield [%]"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        controls_layout.addWidget(self.year_combo_table)
        controls_layout.addWidget(self.show_button_table)

        layout.addLayout(controls_layout)
        layout.addWidget(self.table)
        self.table_tab.setLayout(layout)

    def setup_plot_tab(self):
        layout = QVBoxLayout()
        controls_layout = QHBoxLayout()

        self.year_combo_plot = QComboBox()
        self.plot_button_plot = QPushButton("Plot Summary Data")
        self.plot_button_plot.clicked.connect(self.plot_summary_data)
        
        self.canvas_plot = PlotCanvas(self, width=10, height=6)
        self.canvas_plot.setVisible(False)

        controls_layout.addWidget(self.year_combo_plot)
        controls_layout.addWidget(self.plot_button_plot)

        layout.addLayout(controls_layout)
        layout.addWidget(self.canvas_plot, 1)
        layout.addStretch()
        self.plot_tab.setLayout(layout)

        self.load_initial_data()

    def load_initial_data(self):
        years = set()
        for machine in self.machines.values():
            if hasattr(machine, 'df'):
                years.update(machine.df['Year'].unique())

        for combo in [self.year_combo_table, self.year_combo_plot]:
            combo.addItems([str(int(year)) for year in sorted(years, reverse=True)])

    def gather_data(self, selected_year):
        dfs = []
        for machine_name, machine in self.machines.items():
            if hasattr(machine, 'df'):
                df = machine.df.copy()
                df['Machine'] = machine_name
                df['Bandlänge'] = pd.to_numeric(df['Bandlänge'], errors='coerce')
                df['Ausschusslänge'] = pd.to_numeric(df['Ausschusslänge'], errors='coerce')
                df['Prozess-Datum'] = pd.to_datetime(df['Prozess-Datum'], errors='coerce')
                df = df[df['Year'] == selected_year]  # Filter by selected year
                dfs.append(df)
        
        if dfs:
            return pd.concat(dfs, ignore_index=True)
        else:
            return pd.DataFrame()

    def show_summary_data(self):
        selected_year = int(self.year_combo_table.currentText())
        df = self.gather_data(selected_year)
        if df.empty:
            print("No data available.")
            return

        summary = df.groupby('Machine').agg({
            'Bandlänge': 'sum',
            'Ausschusslänge': 'sum'
        })
        summary['Yield [%]'] = ((summary['Bandlänge'] - summary['Ausschusslänge']) / summary['Bandlänge']) * 100

        self.table.setRowCount(0)
        for i, machine in enumerate(self.machine_order):
            if machine in summary.index:
                row = summary.loc[machine]
                self.table.insertRow(i)
                self.table.setItem(i, 0, QTableWidgetItem(machine))
                self.table.setItem(i, 1, QTableWidgetItem(f"{row['Bandlänge']:.0f}"))  # Round to integer
                self.table.setItem(i, 2, QTableWidgetItem(f"{row['Ausschusslänge']:.0f}"))  # Round to integer
                self.table.setItem(i, 3, QTableWidgetItem(f"{row['Yield [%]']:.2f}"))

                for col in range(self.table.columnCount()):
                    item = self.table.item(i, col)
                    if item:
                        item.setTextAlignment(Qt.AlignCenter)

    def plot_summary_data(self):
        selected_year = int(self.year_combo_plot.currentText())
        df = self.gather_data(selected_year)
        if df.empty:
            print("No data available.")
            return

        df['Month'] = df['Prozess-Datum'].dt.month
        tape_data = df.groupby(['Month', 'Machine'])['Bandlänge'].sum().unstack(fill_value=0)
        scrap_data = df.groupby('Month')['Ausschusslänge'].sum()

        all_months = range(1, 13)
        tape_data = tape_data.reindex(all_months, fill_value=0)
        scrap_data = scrap_data.reindex(all_months, fill_value=0)
        scrap_data = pd.DataFrame({'Scrap': scrap_data})

        available_machines = [machine for machine in self.machines.keys() if machine in tape_data.columns]

        self.canvas_plot.setVisible(True)
        self.canvas_plot.plot_summary(tape_data, scrap_data, f'Summary of Tape and Scrap for {selected_year}', 'Month', self.color_map, available_machines)
        self.canvas_plot.draw()
        self.canvas_plot.flush_events()

class Summary(QWidget):
    def __init__(self, epol0e, isd1a, deck1a, seed1a, sl1ab, ag1a, schn1a, me1a_ag, me1a_cu, tsxl):
        super().__init__()
        self.epol0e = epol0e
        self.isd1a = isd1a
        self.deck1a = deck1a
        self.seed1a = seed1a
        self.sl1ab = sl1ab
        self.ag1a = ag1a
        self.schn1a = schn1a
        self.me1a_ag = me1a_ag
        self.me1a_cu = me1a_cu
        self.tsxl = tsxl
        self.initialize_ui()

    def initialize_ui(self):
        self.tabs = QTabWidget()
        self.ubl_tab = SummaryTab(
            {
                'EPOL0E': self.epol0e,
                'ISD1A': self.isd1a,
                'DECK1A': self.deck1a,
                'SEED1A': self.seed1a,
                'SL1AB': self.sl1ab,
                'AG1A': self.ag1a,
                'TSXL': self.tsxl
            },
            {
                'EPOL0E': 'tab:blue',
                'ISD1A': 'tab:orange',
                'DECK1A': 'tab:green',
                'SEED1A': 'tab:purple',
                'SL1AB': 'tab:cyan',
                'AG1A': 'tab:olive',
                'TSXL': 'tab:pink'
            },
            ['EPOL0E', 'ISD1A', 'DECK1A', 'SEED1A', 'SL1AB', 'AG1A', 'TSXL']
        )
        self.kbl_tab = SummaryTab(
            {
                'SCHN1A': self.schn1a,
                'ME1A Ag': self.me1a_ag,
                'ME1A Cu': self.me1a_cu
            },
            {
                'SCHN1A': 'black',
                'ME1A Ag': 'tab:gray',
                'ME1A Cu': 'tab:brown'
            },
            ['SCHN1A', 'ME1A Ag', 'ME1A Cu']
        )

        self.tabs.addTab(self.ubl_tab, "uBL")
        self.tabs.addTab(self.kbl_tab, "kBL")

        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        self.setLayout(layout)